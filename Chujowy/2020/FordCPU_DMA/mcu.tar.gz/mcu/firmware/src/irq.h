#ifndef __IRQ_H__
#define __IRQ_H__

#include <stdint.h>

// From crt0
extern uint32_t _irq_maskirq(uint32_t);

#endif
