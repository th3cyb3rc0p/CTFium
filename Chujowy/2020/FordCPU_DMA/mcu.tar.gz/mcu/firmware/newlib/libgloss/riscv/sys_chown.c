#include <machine/syscall.h>

//----------------------------------------------------------------------
// chown
//----------------------------------------------------------------------
// Stub.

int _chown(const char *path, uid_t owner, gid_t group)
{
  return -1;
}

