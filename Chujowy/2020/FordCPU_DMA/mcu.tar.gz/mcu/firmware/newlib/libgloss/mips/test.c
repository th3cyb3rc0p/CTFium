main()
{
  outbyte ('&');
  outbyte ('@');
  outbyte ('$');
  outbyte ('%');

  /* whew, we made it */
  
  print ("\r\nDone...");

  return;
}
